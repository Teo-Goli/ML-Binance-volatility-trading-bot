In this folder goes filenames with extention .exs
exs files are lists of pairs to be traded.
ex module1.exs:
	ETHUSDT
	BTCUSDT